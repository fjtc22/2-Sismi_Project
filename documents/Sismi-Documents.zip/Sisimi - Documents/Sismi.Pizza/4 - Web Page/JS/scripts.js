function chart(){
		var colore = 'rgb(0, 0, 0, 0.14)'; // Colori Generici
	
	// Variabili generiche
		
		var i = 0; // Variabile per muoversi tra gli array
		var p = 0; // Limite del Array Locale
		
		// Variabili per l'animazione
		
		var a 
		
		var s = 0; 
		var v = 0;
		
		var l = 0;
		var m = 0;
		
		var t = 0;
		
		var id = 0; // Array che deve decrementare
		var ip = 0; // Array che deve incrementare
		
	// Database locale
		
		var up_x = [16600, 16636, 16652, 16668,
					16720, 16604, 16640, 16656,
					16692, 16632, 16624, 16652,
					16724, 16648, 16580, 16640,
					16760, 16724, 16756, 16652,
					16616, 16624, 16620, 16700,16620, 16596, 16748, 16692,16600, 16640, 16608, 16704,16680, 16680, 16636, 16560,16600, 16748, 16624, 16588,16616, 16636, 16580, 16568,16636, 16628, 16600, 16632,16700, 16532, 16632, 16668,16648, 16644, 16708, 16652,16572, 16596, 16660, 16604];
		
		var up_y = [2288, 2032, 2144, 2188,
					2052, 2120, 2128, 2028,
					2044, 2056, 2088, 2024,
					2164, 2112, 2052, 2164,
					2020, 2356, 2208, 2064,
					2120, 2068, 2080, 2236,
			        2200, 2132, 2124, 2052,
			        2048, 2164, 2192, 1868,
			        2052, 2052, 2088, 2092,
			        1984, 2124, 2072, 2220,
			        2068, 2056, 2056, 2232,
			        2176, 2104, 2032, 2176,
			        2148, 2156, 2196, 2144,
			        2040, 2236, 2060, 2212,
			        2116, 2132, 2204, 2028];
		
		var up_r = [316, 308, 324, 260,
					340, 352, 280, 280,
					228, 284, 272, 296,
					260, 360, 316, 308,
					264, 236, 256, 376,
					300, 296, 212, 268,
			        340, 204, 312, 340,
		            296, 272, 296, 332,
			        268, 300, 208, 288,
			        384, 324, 184, 172,
				    308, 232, 176, 216,
				    356, 236, 308, 228,
				    216, 256, 276, 236,
				    296, 256, 344, 252,
				    248, 320, 304, 236];
			
	// Valori generici dei caratteri
		
		Chart.defaults.global.defaultFontFamily = 'Poppins';
		Chart.defaults.global.defaultFontSize = 11;
		Chart.defaults.global.defaultFontColor = '#A6A6A6';
		
	// Array dei 20 punti da tenere a memoria
		
		var p1 =  [0, 0, 0];
		var p2 =  [0, 0, 0];
		var p3 =  [0, 0, 0];
		var p4 =  [0, 0, 0];
		var p5 =  [0, 0, 0];
		var p6 =  [0, 0, 0];
		var p7 =  [0, 0, 0];
		var p8 =  [0, 0, 0];
		var p9 =  [0, 0, 0];
		var p10 = [0, 0, 0];
		var p11 = [0, 0, 0];
		var p12 = [0, 0, 0];
		var p13 = [0, 0, 0];
		var p14 = [0, 0, 0];
		var p15 = [0, 0, 0];
		var p16 = [0, 0, 0];
		var p17 = [0, 0, 0];
		var p18 = [0, 0, 0];
		var p19 = [0, 0, 0];
		var p20 = [0, 0, 0];
		var p21 = [0, 0, 0];
		var p22 = [0, 0, 0];
		var p23 = [0, 0, 0];
		var p24 = [0, 0, 0];
		var p25 = [0, 0, 0];
		var p26 = [0, 0, 0];
		var p27 = [0, 0, 0];
		var p28 = [0, 0, 0];
		var p29 = [0, 0, 0];
		var p30 = [0, 0, 0];
		var p31 = [0, 0, 0];
		var p32 = [0, 0, 0];
		var p33 = [0, 0, 0];
		var p34 = [0, 0, 0];
		var p35 = [0, 0, 0];
		var p36 = [0, 0, 0];
		var p37 = [0, 0, 0];
		var p38 = [0, 0, 0];
		var p39 = [0, 0, 0];
		var p40 = [0, 0, 0];
		
		
     let grafico = document.getElementById('grafico').getContext('2d');
	 
	 // Stampa del grafico
		
     var graficobubble = new Chart(grafico, {
	                     type:'bubble',
	                     data: { 
							 datasets: [
								 {
								 label: ['Punto 1'],
								 data: [{x: p1[0], y: p1[1], r: p1[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 2'],
								 data: [{x: p2[0], y: p2[1], r: p2[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 3'],
								 data: [{x: p3[0], y: p3[1], r: p3[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 4'],
								 data: [{x: p4[0], y: p4[1], r: p4[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 5'],
								 data: [{x: p5[0], y: p5[1], r: p5[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 6'],
								 data: [{x: p6[0], y: p6[1], r: p6[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 7'],
								 data: [{x: p7[0], y: p7[1], r: p7[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 8'],
								 data: [{x: p8[0], y: p8[1], r: p8[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 9'],
								 data: [{x: p9[0], y: p9[1], r: p9[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 10'],
								 data: [{x: p10[0], y: p10[1], r: p10[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 11'],
								 data: [{x: p11[0], y: p11[1], r: p11[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 12'],
								 data: [{x: p12[0], y: p12[1], r: p12[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 13'],
								 data: [{x: p13[0], y: p13[1], r: p13[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 14'],
								 data: [{x: p14[0], y: p14[1], r: p14[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 15'],
								 data: [{x: p15[0], y: p15[1], r: p15[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 16'],
								 data: [{x: p16[0], y: p16[1], r: p16[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 17'],
								 data: [{x: p17[0], y: p17[1], r: p17[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 18'],
								 data: [{x: p18[0], y: p18[1], r: p18[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 19'],
								 data: [{x: p19[0], y: p19[1], r: p19[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 20'],
								 data: [{x: p20[0], y: p20[1], r: p20[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 21'],
								 data: [{x: p21[0], y: p21[1], r: p21[2]}],
								 backgroundColor: colore}, 
								 {
								 label: ['Punto 22'],
								 data: [{x: p22[0], y: p22[1], r: p22[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 23'],
								 data: [{x: p23[0], y: p23[1], r: p23[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 24'],
								 data: [{x: p24[0], y: p24[1], r: p24[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 25'],
								 data: [{x: p25[0], y: p25[1], r: p25[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 26'],
								 data: [{x: p26[0], y: p26[1], r: p26[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 27'],
								 data: [{x: p27[0], y: p27[1], r: p27[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 28'],
								 data: [{x: p28[0], y: p28[1], r: p28[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 29'],
								 data: [{x: p29[0], y: p29[1], r: p29[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 30'],
								 data: [{x: p30[0], y: p30[1], r: p30[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 31'],
								 data: [{x: p31[0], y: p31[1], r: p31[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 32'],
								 data: [{x: p32[0], y: p32[1], r: p32[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 33'],
								 data: [{x: p33[0], y: p33[1], r: p33[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 34'],
								 data: [{x: p34[0], y: p34[1], r: p34[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 35'],
								 data: [{x: p35[0], y: p35[1], r: p35[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 36'],
								 data: [{x: p36[0], y: p36[1], r: p36[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 37'],
								 data: [{x: p37[0], y: p37[1], r: p37[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 38'],
								 data: [{x: p38[0], y: p38[1], r: p38[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 39'],
								 data: [{x: p39[0], y: p39[1], r: p39[2]}],
								 backgroundColor: colore},
								 {
								 label: ['Punto 40'],
								 data: [{x: p40[0], y: p40[1], r: p40[2]}],
								 backgroundColor: colore}
								 ]
						 },
		                 options:{
							 scales: {
								 xAxes: [{
									 gridLines: {
										 display:false
									 },
									 ticks: {
										 display:false,
										 min: 16500,
										 max: 16800,
										 stepSize: 50
									 }
								 }],
								 yAxes: [{
									 gridLines: {
										 display:false
									 },
									 ticks: {
										 display:false,
										 min: -5000,
										 max: -1500,
										 stepSize: 500
									 }
								 }]
							 },
							 legend:{
								 display: false
							 },
							 animation: {
								 duration: 0
							 },
							 responsive: true,
							 maintainAspectRatio: false,
							 tooltips: {
								 enabled: false
							 }
						 }
	 });
	
	 // Upgrade del grafico
		
	 setInterval(updatedata(), 3000);
		
	function updatedata(){
		 
		 // Definizione del valore ip e id per capire quale bolla deve fare fade in e quale fade out
		 
		 if (i <= 19){ip = i + 20;
					 id = i;};
		 if (i > 19){ip = i - 20;
					 id = i;};
		 
		 // Funzione di Animazione
		 
		 animazionebubble();
		 
		 // Lettura massima di 40 valori animati
		 
		 i++;
		 p++;
		 if (i == 40){i=0};
		 if (p == 40){p=0};
	 } 
		
	 function animazionebubble (){
		 
		 // Definizione del raggio massimo e degli step incrimentali per Fade In
		 
		 s = up_r[p] * 0.8;  // Variabile per modificare il rapoorto Valore/Pixel
		 s = s / 60;
		 v = 0;
		 
		 // Definizione del raggio massimo e degli step diminutivi Fade Out
		 
		 m = graficobubble.data.datasets[ip].data[0].r;
		 l = m / 60;
		 
		 // Funzione di animanimazione che si ripete ogni 100ms
	
		 a = setInterval(animationstep, 50);
		 
	 };
		
     function animationstep(){
		 
		 // Modifica dei raggi da essere modificati
		 
		 m = m - l;
		 
		 // Render grafico
		 
		 graficobubble.data.datasets[id].data[0].x = up_x[p];
		 graficobubble.data.datasets[id].data[0].y = up_y[p] * -1;
		 graficobubble.data.datasets[id].data[0].r = v;
		 graficobubble.data.datasets[ip].data[0].r = m;
		 graficobubble.update();
		 
		 // Limite del animazione
		 
		 t++;
		 v = v + s;
		 
		 if (v > 300){
		 document.getElementById('schermo').innerHTML = v;
		 }
			 
		 if (t == 60){
			 t = 0;
			 v = 0;
			 clearInterval(a);
		 }
	
		
	}
		
}

// JavaScript Document